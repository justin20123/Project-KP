

<?php $__env->startSection('menu'); ?>
<div class="portlet-title">
    <div style="display: inline-block; margin: 15px; font-size: 25px; font-weight: bold;">
        List Pengajar
    </div>

    <?php if(str_contains(Auth::user()->role, 'pengajar')): ?>
    <div style="float: right; margin: 15px;">
        <a href="<?php echo e(route('pengajar.create')); ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i>Add</a>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<div style="margin: 15px; font-size: 20px;">
    <strong>List Pengajar</strong>
</div>
<div class="table-responsive">
    <table id="pengajar" class="table table-striped" style="width:100%">
        <thead class="table-border-bottom-0">
            <tr>
                <th>Nomor</th>
                <th>Nama Lengkap</th>
                <th>Alamat</th>
                <th>Email</th>
                <th>Umur</th>
                <th>Last Login</th>
                <?php if(str_contains(Auth::user()->role, 'pengajar')): ?>
                    <th>Edit</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if(count($pengajar) == 0): ?>
            <tr>
                <td class="text-center" colspan="8">Tidak ada Pengajar yang terdata</td>
            </tr>
            <?php else: ?>
            <?php $__currentLoopData = $pengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($p->nama); ?></td>
                <td><?php echo e($p->alamat); ?></td>
                <td><?php echo e($p->email); ?></td>
                <td><?php echo e($p->umur); ?></td>
                <td><?php echo e($p->last_login); ?></td>

                <?php if(str_contains(Auth::user()->role, 'pengajar')): ?>
                    <td class="text-center"><a href="<?php echo e(route('pengajar.edit', $p->id)); ?>"
                            class="btn btn-sm btn-primary"><i class='bx bx-edit-alt'></i></a>
                    </td>

                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('#pengajar').DataTable({
            "scrollX": true
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sneat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project KP\kp\resources\views/pengajar/index.blade.php ENDPATH**/ ?>