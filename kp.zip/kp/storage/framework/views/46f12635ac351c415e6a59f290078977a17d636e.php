

<?php $__env->startSection('content'); ?>
<div class="modal fade" id="modal-buka-absensi" tabindex="-1" role="dialog"
                    aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal"
                                    aria-hidden="true"></button>
                                <h4 class="modal-title">Modal update 1</h4>
                            </div>
                            <div class="modal-body">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-success" id="buka_absensi">Save changes</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
    <div style="display: inline-block; margin: 15px; font-size: 25px; font-weight: bold;">
        List Pelatihan
    </div>
</div>
<?php if(session('status')): ?>
<div class="alert alert-success"><?php echo e(session('status')); ?></div>
<?php endif; ?>
<section>
    <div class="container px-2 px-lg-2 mt-2">
        <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
            <?php $__currentLoopData = $list_pelatihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelatihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col mb-5">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <div class="text-center">
                            <h5 class="fw-bolder"><?php echo e($pelatihan->nama); ?></h5>
                            <h5 class="fw-bolder"><?php echo e($pelatihan->jadwal_pelatihan); ?></h5>
                            <hr class="hr" />
                            
                            <?php if(str_contains(Auth::user()->role, 'pengajar')): ?>
                            <button onclick="formBukaAbsensi(<?php echo e($pelatihan->id); ?>)" style="border: none; background-color:#8080FF">Buka absensi</button>
                            <button onclick="lihat_absensi('peserta')" style="border: none;">Lihat absensi</button>
                            <hr class="hr" />

                            <button onclick="tutup_absensi()" style="border: none;background-color:#ff0103 ">Tutup absensi</button>
                            <?php endif; ?>
                            <?php if(str_contains(Auth::user()->role, 'peserta')): ?>
                            <button onclick="do_absensi()" style="border: none; background-color:#8080FF">Absen</button>
                            <button onclick="lihat_absensi('peserta')" style="border: none;">Lihat kehadiran</button>
                            <?php endif; ?>


                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->startSection('script'); ?>
<script>
    jQuery(document).ready(function() {
        App.init();
        $("#buka_absensi").on("click", function() {
                $("#form-buka-absensi").submit();
            });

            
    })
    function formBukaAbsensi(id) {

            $.get("<?php echo e(url('buka_absensi')); ?>/" + id,
                function(data) {
                    $("#modal-buka-absensi .modal-body").html(data);
                    $("#modal-buka-absensi").modal("show");
                },
            );
        }
 function buka_absensi(nomor_angkatan, idpelatihan) {
        $.ajax({
            type: 'GET',
            url: "<?php echo e(route('absensi.create')); ?>",
            data: {
                '_token': '<?php echo csrf_token(); ?>',
                'nomor_angkatan': nomor_angkatan,
                'idpelatihan': idpelatihan,
            },
            success: function (data) {
                if (data['status'] == 'success') {
                    window.location.reload(true);
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sneat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project KP\kp\resources\views/pelatihan/index.blade.php ENDPATH**/ ?>