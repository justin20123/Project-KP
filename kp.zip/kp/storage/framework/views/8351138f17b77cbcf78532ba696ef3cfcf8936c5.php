<?php if(auth()->guard()->check()): ?>
    <nav
        class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
        id="layout-navbar">
        <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
            <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
            </a>
        </div>

        <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                Hello, <?php echo e(Auth::user()->nama); ?>: (<?php echo e(Auth::user()->role); ?>)
        
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH D:\Project KP\kp\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>