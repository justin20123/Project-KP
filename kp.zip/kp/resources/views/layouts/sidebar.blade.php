<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
      <a href="index.html" class="app-brand-link">
        <span class="app-brand-text demo menu-text fw-bolder ms-2">Fashion Brand</span>
      </a>
    </div>

    <div class="menu-inner-shadow"></div>

    
  </aside>
