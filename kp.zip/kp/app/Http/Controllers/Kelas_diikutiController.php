<?php

namespace App\Http\Controllers;

use App\Models\Kelas_diikuti;
use Illuminate\Http\Request;

class Kelas_diikutiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kelas_diikuti  $kelas_diikuti
     * @return \Illuminate\Http\Response
     */
    public function show(Kelas_diikuti $kelas_diikuti)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kelas_diikuti  $kelas_diikuti
     * @return \Illuminate\Http\Response
     */
    public function edit(Kelas_diikuti $kelas_diikuti)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kelas_diikuti  $kelas_diikuti
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kelas_diikuti $kelas_diikuti)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kelas_diikuti  $kelas_diikuti
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kelas_diikuti $kelas_diikuti)
    {
        //
    }
}
